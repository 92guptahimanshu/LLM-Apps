{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Simple Gen AI APP Using Langchain"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {},
   "outputs": [],
   "source": [
    "import os\n",
    "from dotenv import load_dotenv\n",
    "load_dotenv()\n",
    "\n",
    "os.environ['OPENAI_API_KEY']=os.getenv(\"OPENAI_API_KEY\")\n",
    "## Langsmith Tracking\n",
    "os.environ[\"LANGCHAIN_API_KEY\"]=os.getenv(\"LANGCHAIN_API_KEY\")\n",
    "os.environ[\"LANGCHAIN_TRACING_V2\"]=\"true\"\n",
    "os.environ[\"LANGCHAIN_PROJECT\"]=os.getenv(\"LANGCHAIN_PROJECT\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {},
   "outputs": [],
   "source": [
    "## Data Ingestion--From the website we need to scrape the data\n",
    "from langchain_community.document_loaders import WebBaseLoader"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<langchain_community.document_loaders.web_base.WebBaseLoader at 0x23ec45de0b0>"
      ]
     },
     "execution_count": 5,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "loader=WebBaseLoader(\"https://docs.smith.langchain.com/tutorials/Administrators/manage_spend\")\n",
    "loader"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "[Document(page_content='\\n\\n\\n\\n\\nOptimize tracing spend on LangSmith | 🦜️🛠️ LangSmith\\n\\n\\n\\n\\n\\n\\n\\nSkip to main contentGo to API DocsSearchGo to AppQuick startTutorialsAdministratorsOptimize tracing spend on LangSmithDevelopersHow-to guidesConceptsReferencePricingSelf-hostingTutorialsAdministratorsOptimize tracing spend on LangSmithOn this pageOptimize tracing spend on LangSmithRecommended ReadingBefore diving into this content, it might be helpful to read the following:Data Retention Conceptual DocsUsage Limiting Conceptual DocsnoteSome of the features mentioned in this guide are not currently available in Enterprise plan due to its\\ncustom nature of billing. If you are on Enterprise plan and have questions about cost optimization,\\nplease reach out to your sales rep or support@langchain.dev.This tutorial walks through optimizing your spend on LangSmith. In it, we will learn how to optimize existing spend\\nand prevent future overspend on a realistic real-world example. We will use an existing LangSmith organization with high usage.\\nConcepts can be transferred to your own organization.Problem Setup\\u200bIn this tutorial, we take an existing organization that has three workspaces, one for each deployment stage\\n(Dev, Staging, and Prod):Understand your current usage\\u200bThe first step of any optimization process is to understand current usage. LangSmith gives two ways to do this: Usage Graph\\nand Invoices.Usage Graph\\u200bThe usage graph lets us examine how much of each usage based pricing metric we have consumed lately. It does not directly show\\nspend (which we will see later on our draft invoice).We can navigate to the Usage Graph under Settings -> Usage and Billing -> Usage Graph.We see in the graph above that there are two usage metrics that LangSmith charges for:LangSmith Traces (Base Charge)LangSmith Traces (Extended Data Retention Upgrades).The first metric tracks all traces that you send to LangSmith. The second tracks all traces that also have our Extended 400 Day Data Retention.\\nFor more details, see our data retention conceptual docs. Notice that these graphs look\\nidentical, which will come into play later in the tutorial.LangSmith Traces usage is measured per workspace, because workspaces often represent development environments (as in our example),\\nor teams within an organization. As a LangSmith administrator, we want to understand spend granularly per each of these units. In\\nthis case where we just want to cut spend, we can focus on the environment responsible for the majority of costs first for the greatest savings.noteLangSmith\\'s Usage Graph and Invoice use the term tenant_id to refer to a workspace ID. They are interchangeable.In the above image, the vast majority of usage is in the workspace with ID c27dd32c-7c80-4e8c-acde-bfcb67a90ab2. We can\\ngo to Settings -> Workspaces, and hover our mouse over the Workspace ID button to find the one with a matching ID. In\\nthis case, it\\'s the Prod workspace:Invoices\\u200bWe understand what usage looks like in terms of traces, but we now need to translate that into spend. To do so,\\nwe head to the Invoices tab. The first invoice that will appear on screen is a draft of your current month\\'s\\ninvoice, which shows your running spend thus far this month.In the above GIF, we see that the charges for LangSmith Traces are broken up by \"tenant_id\" (i.e. Workspace ID), meaning we can track tracing spend\\non each of our workspaces. In the first few days of June, the vast majority of the total spend of ~$2,000 is in our production\\nworkspace. Further, the majority of spend in that workspace was on extended data retention trace upgrades.These upgrades occur for two reasons:You use extended data retention tracing, meaning that, by default, your traces are retained for 400 daysYou use base data retention tracing, and use a feature that automatically extends the data retention of a trace (see our Auto-Upgrade conceptual docs)Given that the number of total traces per day is equal to the number of extended retention traces per day, it\\'s most likely the\\ncase that this org is using extended data retention tracing everywhere. As such, we start by optimizing our retention settings.Optimization 1: manage data retention\\u200bLangSmith charges differently based on a trace\\'s data retention (see our data retention conceptual docs),\\nwhere short-lived traces are an order of magnitude less expensive than ones that last for a long time. In this optimization, we will\\nshow how to get optimal settings for data retention without sacrificing historical observability, and\\nshow the effect it has on our bill.Change org level retention defaults for new projects\\u200bWe navigate to the Usage configuration tab, and look at our organization level retention settings. Modifying this setting affects all new projects that are\\ncreated going forward in all workspaces in our org.noteFor backwards compatibility, older organizations may have this defaulted to Extended. Organizations created after June 3rd\\nhave this defaulted to Base.Change project level retention defaults\\u200bOur existing projects have not changed their data retention settings, so we can change these on the individual project pages.We navigate to Projects -> <your project name>, click the data retention drop down, and modify it to base retention. As\\nwith the organization level setting, this will only affect retention (and pricing) for traces going forward.[COMING SOON] Keep around a percentage of traces for extended data retention\\u200bWe may not want all our traces to expire after 14 days if we care about historical debugging. As such, we can take advantage\\nof LangSmith\\'s built in ability to do server side sampling for extended data retention.Choosing the right percentage of runs to sample depends on your use case. We will arbitrarily pick 10% of runs here, but will\\nleave it to the user to find the right value that balances collecting rare events and cost constraints.LangSmith automatically upgrades the data retention for any trace that matches a run rule in our automations product (see our run rules docs). On the\\nprojects page, click Add Rule, and configure the rule as follows:Run rules match on runs rather than traces. Runs are single units of work within an LLM application\\'s API handling. Traces\\nare end to end API calls (learn more about tracing concepts in LangSmith). This means a trace can\\nbe thought of as a tree of runs making up an API call. When a run rule matches any run within a trace, the trace\\'s full run tree\\nupgrades to be retained for 400 days.Therefore, to make sure we have the proper sampling rate on traces, we can add a filter condition to only match the \"root\" run in\\nthe run tree. This is distinct per trace, so our 10% sampling will upgrade 10% of traces, rather 10% of runs, which could correspond to\\nmore than 10% of traces.noteIf you want to keep a subset of traces for longer than 400 days for data collection purposes, you can create another run\\nrule that sends some runs to a dataset of your choosing. A dataset allows you to store the trace inputs and outputs (e.g., as a key-value dataset),\\nand will persist indefinitely, even after the trace gets deleted.See results after 7 days\\u200bWhile the total amount of traces per day stayed the same, the extended data retention traces was cut heavily.This translates to the invoice, where we\\'ve only spent about $900 in the last 7 days, as opposed to $2,000 in the previous 4.\\nThat\\'s a cost reduction of nearly 75% per day!Optimization 2: limit usage\\u200bIn the previous section, we managed data retention settings to optimize existing spend. In this section, we will\\nuse usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we\\'ve\\nbeen tracking on our usage graph. We can use these in tandem to have granular control over spend.To set limits, we navigate back to Settings -> Usage and Billing -> Usage configuration. There is a table at the\\nbottom of the page that lets you set usage limits per workspace. For each workspace, the two limits appear, along\\nwith a cost estimate:Lets start by setting limits on our production usage, since that is where the majority of spend comes from.Setting a good total traces limit\\u200bPicking the right \"total traces\" limit depends on the expected load of traces that you will send to LangSmith. You should\\nclearly think about your assumptions before setting a limit.For example:Current Load: Our gen AI application is called between 1.2-1.5 times per second, and each API request has a trace associated with it,\\nmeaning we log around 100,000-130,000 traces per dayExpected Growth in Load: We expect to double in size in the near future.From these assumptions, we can do a quick back-of-the-envelope calculation to get a good limit of:limit = current_load_per_day * expected_growth * days/month      = 130,000 * 2 * 30      = 7,800,000 traces / monthWe click on the edit icon on the right side of the table for our Prod row, and can enter this limit as follows:noteWhen set without the extended data retention traces limit, the maximum cost estimator assumes that all traces are using extended data retention.Cutting maximum spend with an extended data retention limit\\u200bIf we are not a big enterprise, we may shudder at the ~$40k per month bill.We saw from Optimization 1 that the easiest way to cut cost was through managing data retention.\\nThe same can be said for limits. If we only want to keep ~10% of traces to be around more than 14 days, we can set a limit on the maximum\\nhigh retention traces we can keep. That would be .10 * 7,800,000 = 780,000.As we can see, the maximum cost is cut from ~40k per month to ~7.5k per month, because we no longer allow as many expensive\\ndata retention upgrades. This lets us be confident that new users on the platform will not accidentally cause cost to balloon.noteThe extended data retention limit can cause features other than traces to stop working once reached. If you plan to\\nuse this feature, please read more about its functionality here.Set dev/staging limits and view total spent limit across workspaces\\u200bFollowing the same logic for our dev and staging environments, whe set limits at 10% of the production\\nlimit on usage for each workspace.While this works with our usage pattern, setting good dev and staging limits may vary depending on\\nyour use case with LangSmith. For example, if you run evals as part of CI/CD in dev or staging, you may\\nwant to be more liberal with your usage limits to avoid test failures.Now that our limits are set, we can see that LangSmith shows a maximum spend estimate across all workspaces:With this estimator, we can be confident that we will not end up with an unexpected credit card bill at the end of the month.Summary\\u200bIn this tutorial, we learned how to:Cut down our existing costs with data retention policiesPrevent future overspend with usage limitsIf you have questions about further optimizing your spend, please reach out to support@langchain.dev.Was this page helpful?You can leave detailed feedback on GitHub.PreviousTutorialsNextAdd observability to your LLM applicationProblem SetupUnderstand your current usageUsage GraphInvoicesOptimization 1: manage data retentionChange org level retention defaults for new projectsChange project level retention defaultsCOMING SOON Keep around a percentage of traces for extended data retentionSee results after 7 daysOptimization 2: limit usageSetting a good total traces limitCutting maximum spend with an extended data retention limitSet dev/staging limits and view total spent limit across workspacesSummaryCommunityDiscordTwitterGitHubDocs CodeLangSmith SDKPythonJS/TSMoreHomepageBlogLangChain Python DocsLangChain JS/TS DocsCopyright © 2024 LangChain, Inc.\\n\\n\\n\\n', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'})]"
      ]
     },
     "execution_count": 6,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "docs=loader.load()\n",
    "docs"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "metadata": {},
   "outputs": [],
   "source": [
    "### Load Data--> Docs-->Divide our Docuemnts into chunks dcouments-->text-->vectors-->Vector Embeddings--->Vector Store DB\n",
    "from langchain_text_splitters import RecursiveCharacterTextSplitter\n",
    "\n",
    "text_splitter=RecursiveCharacterTextSplitter(chunk_size=1000,chunk_overlap=200)\n",
    "documents=text_splitter.split_documents(docs)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "[Document(page_content='Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='Skip to main contentGo to API DocsSearchGo to AppQuick startTutorialsAdministratorsOptimize tracing spend on LangSmithDevelopersHow-to guidesConceptsReferencePricingSelf-hostingTutorialsAdministratorsOptimize tracing spend on LangSmithOn this pageOptimize tracing spend on LangSmithRecommended ReadingBefore diving into this content, it might be helpful to read the following:Data Retention Conceptual DocsUsage Limiting Conceptual DocsnoteSome of the features mentioned in this guide are not currently available in Enterprise plan due to its\\ncustom nature of billing. If you are on Enterprise plan and have questions about cost optimization,\\nplease reach out to your sales rep or support@langchain.dev.This tutorial walks through optimizing your spend on LangSmith. In it, we will learn how to optimize existing spend\\nand prevent future overspend on a realistic real-world example. We will use an existing LangSmith organization with high usage.', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='and prevent future overspend on a realistic real-world example. We will use an existing LangSmith organization with high usage.\\nConcepts can be transferred to your own organization.Problem Setup\\u200bIn this tutorial, we take an existing organization that has three workspaces, one for each deployment stage\\n(Dev, Staging, and Prod):Understand your current usage\\u200bThe first step of any optimization process is to understand current usage. LangSmith gives two ways to do this: Usage Graph\\nand Invoices.Usage Graph\\u200bThe usage graph lets us examine how much of each usage based pricing metric we have consumed lately. It does not directly show', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='and Invoices.Usage Graph\\u200bThe usage graph lets us examine how much of each usage based pricing metric we have consumed lately. It does not directly show\\nspend (which we will see later on our draft invoice).We can navigate to the Usage Graph under Settings -> Usage and Billing -> Usage Graph.We see in the graph above that there are two usage metrics that LangSmith charges for:LangSmith Traces (Base Charge)LangSmith Traces (Extended Data Retention Upgrades).The first metric tracks all traces that you send to LangSmith. The second tracks all traces that also have our Extended 400 Day Data Retention.\\nFor more details, see our data retention conceptual docs. Notice that these graphs look\\nidentical, which will come into play later in the tutorial.LangSmith Traces usage is measured per workspace, because workspaces often represent development environments (as in our example),', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content=\"identical, which will come into play later in the tutorial.LangSmith Traces usage is measured per workspace, because workspaces often represent development environments (as in our example),\\nor teams within an organization. As a LangSmith administrator, we want to understand spend granularly per each of these units. In\\nthis case where we just want to cut spend, we can focus on the environment responsible for the majority of costs first for the greatest savings.noteLangSmith's Usage Graph and Invoice use the term tenant_id to refer to a workspace ID. They are interchangeable.In the above image, the vast majority of usage is in the workspace with ID c27dd32c-7c80-4e8c-acde-bfcb67a90ab2. We can\\ngo to Settings -> Workspaces, and hover our mouse over the Workspace ID button to find the one with a matching ID. In\\nthis case, it's the Prod workspace:Invoices\\u200bWe understand what usage looks like in terms of traces, but we now need to translate that into spend. To do so,\", metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='this case, it\\'s the Prod workspace:Invoices\\u200bWe understand what usage looks like in terms of traces, but we now need to translate that into spend. To do so,\\nwe head to the Invoices tab. The first invoice that will appear on screen is a draft of your current month\\'s\\ninvoice, which shows your running spend thus far this month.In the above GIF, we see that the charges for LangSmith Traces are broken up by \"tenant_id\" (i.e. Workspace ID), meaning we can track tracing spend\\non each of our workspaces. In the first few days of June, the vast majority of the total spend of ~$2,000 is in our production', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content=\"on each of our workspaces. In the first few days of June, the vast majority of the total spend of ~$2,000 is in our production\\nworkspace. Further, the majority of spend in that workspace was on extended data retention trace upgrades.These upgrades occur for two reasons:You use extended data retention tracing, meaning that, by default, your traces are retained for 400 daysYou use base data retention tracing, and use a feature that automatically extends the data retention of a trace (see our Auto-Upgrade conceptual docs)Given that the number of total traces per day is equal to the number of extended retention traces per day, it's most likely the\\ncase that this org is using extended data retention tracing everywhere. As such, we start by optimizing our retention settings.Optimization 1: manage data retention\\u200bLangSmith charges differently based on a trace's data retention (see our data retention conceptual docs),\", metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='where short-lived traces are an order of magnitude less expensive than ones that last for a long time. In this optimization, we will\\nshow how to get optimal settings for data retention without sacrificing historical observability, and\\nshow the effect it has on our bill.Change org level retention defaults for new projects\\u200bWe navigate to the Usage configuration tab, and look at our organization level retention settings. Modifying this setting affects all new projects that are\\ncreated going forward in all workspaces in our org.noteFor backwards compatibility, older organizations may have this defaulted to Extended. Organizations created after June 3rd\\nhave this defaulted to Base.Change project level retention defaults\\u200bOur existing projects have not changed their data retention settings, so we can change these on the individual project pages.We navigate to Projects -> <your project name>, click the data retention drop down, and modify it to base retention. As', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content=\"with the organization level setting, this will only affect retention (and pricing) for traces going forward.[COMING SOON] Keep around a percentage of traces for extended data retention\\u200bWe may not want all our traces to expire after 14 days if we care about historical debugging. As such, we can take advantage\\nof LangSmith's built in ability to do server side sampling for extended data retention.Choosing the right percentage of runs to sample depends on your use case. We will arbitrarily pick 10% of runs here, but will\\nleave it to the user to find the right value that balances collecting rare events and cost constraints.LangSmith automatically upgrades the data retention for any trace that matches a run rule in our automations product (see our run rules docs). On the\\nprojects page, click Add Rule, and configure the rule as follows:Run rules match on runs rather than traces. Runs are single units of work within an LLM application's API handling. Traces\", metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='projects page, click Add Rule, and configure the rule as follows:Run rules match on runs rather than traces. Runs are single units of work within an LLM application\\'s API handling. Traces\\nare end to end API calls (learn more about tracing concepts in LangSmith). This means a trace can\\nbe thought of as a tree of runs making up an API call. When a run rule matches any run within a trace, the trace\\'s full run tree\\nupgrades to be retained for 400 days.Therefore, to make sure we have the proper sampling rate on traces, we can add a filter condition to only match the \"root\" run in\\nthe run tree. This is distinct per trace, so our 10% sampling will upgrade 10% of traces, rather 10% of runs, which could correspond to\\nmore than 10% of traces.noteIf you want to keep a subset of traces for longer than 400 days for data collection purposes, you can create another run', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content=\"more than 10% of traces.noteIf you want to keep a subset of traces for longer than 400 days for data collection purposes, you can create another run\\nrule that sends some runs to a dataset of your choosing. A dataset allows you to store the trace inputs and outputs (e.g., as a key-value dataset),\\nand will persist indefinitely, even after the trace gets deleted.See results after 7 days\\u200bWhile the total amount of traces per day stayed the same, the extended data retention traces was cut heavily.This translates to the invoice, where we've only spent about $900 in the last 7 days, as opposed to $2,000 in the previous 4.\\nThat's a cost reduction of nearly 75% per day!Optimization 2: limit usage\\u200bIn the previous section, we managed data retention settings to optimize existing spend. In this section, we will\\nuse usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we've\", metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='use usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we\\'ve\\nbeen tracking on our usage graph. We can use these in tandem to have granular control over spend.To set limits, we navigate back to Settings -> Usage and Billing -> Usage configuration. There is a table at the\\nbottom of the page that lets you set usage limits per workspace. For each workspace, the two limits appear, along\\nwith a cost estimate:Lets start by setting limits on our production usage, since that is where the majority of spend comes from.Setting a good total traces limit\\u200bPicking the right \"total traces\" limit depends on the expected load of traces that you will send to LangSmith. You should\\nclearly think about your assumptions before setting a limit.For example:Current Load: Our gen AI application is called between 1.2-1.5 times per second, and each API request has a trace associated with it,', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='meaning we log around 100,000-130,000 traces per dayExpected Growth in Load: We expect to double in size in the near future.From these assumptions, we can do a quick back-of-the-envelope calculation to get a good limit of:limit = current_load_per_day * expected_growth * days/month      = 130,000 * 2 * 30      = 7,800,000 traces / monthWe click on the edit icon on the right side of the table for our Prod row, and can enter this limit as follows:noteWhen set without the extended data retention traces limit, the maximum cost estimator assumes that all traces are using extended data retention.Cutting maximum spend with an extended data retention limit\\u200bIf we are not a big enterprise, we may shudder at the ~$40k per month bill.We saw from Optimization 1 that the easiest way to cut cost was through managing data retention.\\nThe same can be said for limits. If we only want to keep ~10% of traces to be around more than 14 days, we can set a limit on the maximum', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='The same can be said for limits. If we only want to keep ~10% of traces to be around more than 14 days, we can set a limit on the maximum\\nhigh retention traces we can keep. That would be .10 * 7,800,000 = 780,000.As we can see, the maximum cost is cut from ~40k per month to ~7.5k per month, because we no longer allow as many expensive\\ndata retention upgrades. This lets us be confident that new users on the platform will not accidentally cause cost to balloon.noteThe extended data retention limit can cause features other than traces to stop working once reached. If you plan to\\nuse this feature, please read more about its functionality here.Set dev/staging limits and view total spent limit across workspaces\\u200bFollowing the same logic for our dev and staging environments, whe set limits at 10% of the production\\nlimit on usage for each workspace.While this works with our usage pattern, setting good dev and staging limits may vary depending on', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='limit on usage for each workspace.While this works with our usage pattern, setting good dev and staging limits may vary depending on\\nyour use case with LangSmith. For example, if you run evals as part of CI/CD in dev or staging, you may', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='want to be more liberal with your usage limits to avoid test failures.Now that our limits are set, we can see that LangSmith shows a maximum spend estimate across all workspaces:With this estimator, we can be confident that we will not end up with an unexpected credit card bill at the end of the month.Summary\\u200bIn this tutorial, we learned how to:Cut down our existing costs with data retention policiesPrevent future overspend with usage limitsIf you have questions about further optimizing your spend, please reach out to support@langchain.dev.Was this page helpful?You can leave detailed feedback on GitHub.PreviousTutorialsNextAdd observability to your LLM applicationProblem SetupUnderstand your current usageUsage GraphInvoicesOptimization 1: manage data retentionChange org level retention defaults for new projectsChange project level retention defaultsCOMING SOON Keep around a percentage of traces for extended data retentionSee results after 7 daysOptimization 2: limit usageSetting a', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='defaults for new projectsChange project level retention defaultsCOMING SOON Keep around a percentage of traces for extended data retentionSee results after 7 daysOptimization 2: limit usageSetting a good total traces limitCutting maximum spend with an extended data retention limitSet dev/staging limits and view total spent limit across workspacesSummaryCommunityDiscordTwitterGitHubDocs CodeLangSmith SDKPythonJS/TSMoreHomepageBlogLangChain Python DocsLangChain JS/TS DocsCopyright © 2024 LangChain, Inc.', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'})]"
      ]
     },
     "execution_count": 8,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "documents"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "metadata": {},
   "outputs": [],
   "source": [
    "from langchain_openai import OpenAIEmbeddings\n",
    "embeddings=OpenAIEmbeddings()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "metadata": {},
   "outputs": [],
   "source": [
    "from langchain_community.vectorstores import FAISS\n",
    "vectorstoredb=FAISS.from_documents(documents,embeddings)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 11,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<langchain_community.vectorstores.faiss.FAISS at 0x23ef4d513f0>"
      ]
     },
     "execution_count": 11,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "vectorstoredb"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 18,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "'use usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we\\'ve\\nbeen tracking on our usage graph. We can use these in tandem to have granular control over spend.To set limits, we navigate back to Settings -> Usage and Billing -> Usage configuration. There is a table at the\\nbottom of the page that lets you set usage limits per workspace. For each workspace, the two limits appear, along\\nwith a cost estimate:Lets start by setting limits on our production usage, since that is where the majority of spend comes from.Setting a good total traces limit\\u200bPicking the right \"total traces\" limit depends on the expected load of traces that you will send to LangSmith. You should\\nclearly think about your assumptions before setting a limit.For example:Current Load: Our gen AI application is called between 1.2-1.5 times per second, and each API request has a trace associated with it,'"
      ]
     },
     "execution_count": 18,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "## Query From a vector db\n",
    "query=\"LangSmith has two usage limits: total traces and extended\"\n",
    "result=vectorstoredb.similarity_search(query)\n",
    "result[0].page_content"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 20,
   "metadata": {},
   "outputs": [],
   "source": [
    "from langchain_openai import ChatOpenAI\n",
    "llm=ChatOpenAI(model=\"gpt-4o\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 21,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "RunnableBinding(bound=RunnableBinding(bound=RunnableAssign(mapper={\n",
       "  context: RunnableLambda(format_docs)\n",
       "}), config={'run_name': 'format_inputs'})\n",
       "| ChatPromptTemplate(input_variables=['context'], messages=[HumanMessagePromptTemplate(prompt=PromptTemplate(input_variables=['context'], template='\\nAnswer the following question based only on the provided context:\\n<context>\\n{context}\\n</context>\\n\\n\\n'))])\n",
       "| ChatOpenAI(client=<openai.resources.chat.completions.Completions object at 0x0000023FB8A1DB10>, async_client=<openai.resources.chat.completions.AsyncCompletions object at 0x0000023FB87D31F0>, model_name='gpt-4o', openai_api_key=SecretStr('**********'), openai_proxy='')\n",
       "| StrOutputParser(), config={'run_name': 'stuff_documents_chain'})"
      ]
     },
     "execution_count": 21,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "## Retrieval Chain, Document chain\n",
    "\n",
    "from langchain.chains.combine_documents import create_stuff_documents_chain\n",
    "from langchain_core.prompts import ChatPromptTemplate\n",
    "\n",
    "prompt=ChatPromptTemplate.from_template(\n",
    "    \"\"\"\n",
    "Answer the following question based only on the provided context:\n",
    "<context>\n",
    "{context}\n",
    "</context>\n",
    "\n",
    "\n",
    "\"\"\"\n",
    ")\n",
    "\n",
    "document_chain=create_stuff_documents_chain(llm,prompt)\n",
    "document_chain"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 23,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "'LangSmith has two usage limits: total traces and extended traces. These correspond to the two metrics tracked on their usage graph.'"
      ]
     },
     "execution_count": 23,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "from langchain_core.documents import Document\n",
    "document_chain.invoke({\n",
    "    \"input\":\"LangSmith has two usage limits: total traces and extended\",\n",
    "    \"context\":[Document(page_content=\"LangSmith has two usage limits: total traces and extended traces. These correspond to the two metrics we've been tracking on our usage graph. \")]\n",
    "})"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "However, we want the documents to first come from the retriever we just set up. That way, we can use the retriever to dynamically select the most relevant documents and pass those in for a given question."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 24,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<langchain_community.vectorstores.faiss.FAISS at 0x23ef4d513f0>"
      ]
     },
     "execution_count": 24,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "### Input--->Retriever--->vectorstoredb\n",
    "\n",
    "vectorstoredb"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 26,
   "metadata": {},
   "outputs": [],
   "source": [
    "retriever=vectorstoredb.as_retriever()\n",
    "from langchain.chains import create_retrieval_chain\n",
    "retrieval_chain=create_retrieval_chain(retriever,document_chain)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 27,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "RunnableBinding(bound=RunnableAssign(mapper={\n",
       "  context: RunnableBinding(bound=RunnableLambda(lambda x: x['input'])\n",
       "           | VectorStoreRetriever(tags=['FAISS', 'OpenAIEmbeddings'], vectorstore=<langchain_community.vectorstores.faiss.FAISS object at 0x0000023EF4D513F0>), config={'run_name': 'retrieve_documents'})\n",
       "})\n",
       "| RunnableAssign(mapper={\n",
       "    answer: RunnableBinding(bound=RunnableBinding(bound=RunnableAssign(mapper={\n",
       "              context: RunnableLambda(format_docs)\n",
       "            }), config={'run_name': 'format_inputs'})\n",
       "            | ChatPromptTemplate(input_variables=['context'], messages=[HumanMessagePromptTemplate(prompt=PromptTemplate(input_variables=['context'], template='\\nAnswer the following question based only on the provided context:\\n<context>\\n{context}\\n</context>\\n\\n\\n'))])\n",
       "            | ChatOpenAI(client=<openai.resources.chat.completions.Completions object at 0x0000023FB8A1DB10>, async_client=<openai.resources.chat.completions.AsyncCompletions object at 0x0000023FB87D31F0>, model_name='gpt-4o', openai_api_key=SecretStr('**********'), openai_proxy='')\n",
       "            | StrOutputParser(), config={'run_name': 'stuff_documents_chain'})\n",
       "  }), config={'run_name': 'retrieval_chain'})"
      ]
     },
     "execution_count": 27,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "retrieval_chain"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 28,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "'To set usage limits in LangSmith, navigate to **Settings -> Usage and Billing -> Usage configuration**. There, you will find a table at the bottom of the page that allows you to set usage limits per workspace. The two types of limits you can set are **total traces** and **extended retention traces**, each with an associated cost estimate.'"
      ]
     },
     "execution_count": 28,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "## Get the response form the LLM\n",
    "response=retrieval_chain.invoke({\"input\":\"LangSmith has two usage limits: total traces and extended\"})\n",
    "response['answer']"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 29,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "{'input': 'LangSmith has two usage limits: total traces and extended',\n",
       " 'context': [Document(page_content='use usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we\\'ve\\nbeen tracking on our usage graph. We can use these in tandem to have granular control over spend.To set limits, we navigate back to Settings -> Usage and Billing -> Usage configuration. There is a table at the\\nbottom of the page that lets you set usage limits per workspace. For each workspace, the two limits appear, along\\nwith a cost estimate:Lets start by setting limits on our production usage, since that is where the majority of spend comes from.Setting a good total traces limit\\u200bPicking the right \"total traces\" limit depends on the expected load of traces that you will send to LangSmith. You should\\nclearly think about your assumptions before setting a limit.For example:Current Load: Our gen AI application is called between 1.2-1.5 times per second, and each API request has a trace associated with it,', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       "  Document(page_content=\"more than 10% of traces.noteIf you want to keep a subset of traces for longer than 400 days for data collection purposes, you can create another run\\nrule that sends some runs to a dataset of your choosing. A dataset allows you to store the trace inputs and outputs (e.g., as a key-value dataset),\\nand will persist indefinitely, even after the trace gets deleted.See results after 7 days\\u200bWhile the total amount of traces per day stayed the same, the extended data retention traces was cut heavily.This translates to the invoice, where we've only spent about $900 in the last 7 days, as opposed to $2,000 in the previous 4.\\nThat's a cost reduction of nearly 75% per day!Optimization 2: limit usage\\u200bIn the previous section, we managed data retention settings to optimize existing spend. In this section, we will\\nuse usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we've\", metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       "  Document(page_content='and Invoices.Usage Graph\\u200bThe usage graph lets us examine how much of each usage based pricing metric we have consumed lately. It does not directly show\\nspend (which we will see later on our draft invoice).We can navigate to the Usage Graph under Settings -> Usage and Billing -> Usage Graph.We see in the graph above that there are two usage metrics that LangSmith charges for:LangSmith Traces (Base Charge)LangSmith Traces (Extended Data Retention Upgrades).The first metric tracks all traces that you send to LangSmith. The second tracks all traces that also have our Extended 400 Day Data Retention.\\nFor more details, see our data retention conceptual docs. Notice that these graphs look\\nidentical, which will come into play later in the tutorial.LangSmith Traces usage is measured per workspace, because workspaces often represent development environments (as in our example),', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       "  Document(page_content='defaults for new projectsChange project level retention defaultsCOMING SOON Keep around a percentage of traces for extended data retentionSee results after 7 daysOptimization 2: limit usageSetting a good total traces limitCutting maximum spend with an extended data retention limitSet dev/staging limits and view total spent limit across workspacesSummaryCommunityDiscordTwitterGitHubDocs CodeLangSmith SDKPythonJS/TSMoreHomepageBlogLangChain Python DocsLangChain JS/TS DocsCopyright © 2024 LangChain, Inc.', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'})],\n",
       " 'answer': 'To set usage limits in LangSmith, navigate to **Settings -> Usage and Billing -> Usage configuration**. There, you will find a table at the bottom of the page that allows you to set usage limits per workspace. The two types of limits you can set are **total traces** and **extended retention traces**, each with an associated cost estimate.'}"
      ]
     },
     "execution_count": 29,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "\n",
    "response"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 30,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "[Document(page_content='use usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we\\'ve\\nbeen tracking on our usage graph. We can use these in tandem to have granular control over spend.To set limits, we navigate back to Settings -> Usage and Billing -> Usage configuration. There is a table at the\\nbottom of the page that lets you set usage limits per workspace. For each workspace, the two limits appear, along\\nwith a cost estimate:Lets start by setting limits on our production usage, since that is where the majority of spend comes from.Setting a good total traces limit\\u200bPicking the right \"total traces\" limit depends on the expected load of traces that you will send to LangSmith. You should\\nclearly think about your assumptions before setting a limit.For example:Current Load: Our gen AI application is called between 1.2-1.5 times per second, and each API request has a trace associated with it,', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content=\"more than 10% of traces.noteIf you want to keep a subset of traces for longer than 400 days for data collection purposes, you can create another run\\nrule that sends some runs to a dataset of your choosing. A dataset allows you to store the trace inputs and outputs (e.g., as a key-value dataset),\\nand will persist indefinitely, even after the trace gets deleted.See results after 7 days\\u200bWhile the total amount of traces per day stayed the same, the extended data retention traces was cut heavily.This translates to the invoice, where we've only spent about $900 in the last 7 days, as opposed to $2,000 in the previous 4.\\nThat's a cost reduction of nearly 75% per day!Optimization 2: limit usage\\u200bIn the previous section, we managed data retention settings to optimize existing spend. In this section, we will\\nuse usage limits to prevent future overspend.LangSmith has two usage limits: total traces and extended retention traces. These correspond to the two metrics we've\", metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='and Invoices.Usage Graph\\u200bThe usage graph lets us examine how much of each usage based pricing metric we have consumed lately. It does not directly show\\nspend (which we will see later on our draft invoice).We can navigate to the Usage Graph under Settings -> Usage and Billing -> Usage Graph.We see in the graph above that there are two usage metrics that LangSmith charges for:LangSmith Traces (Base Charge)LangSmith Traces (Extended Data Retention Upgrades).The first metric tracks all traces that you send to LangSmith. The second tracks all traces that also have our Extended 400 Day Data Retention.\\nFor more details, see our data retention conceptual docs. Notice that these graphs look\\nidentical, which will come into play later in the tutorial.LangSmith Traces usage is measured per workspace, because workspaces often represent development environments (as in our example),', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'}),\n",
       " Document(page_content='defaults for new projectsChange project level retention defaultsCOMING SOON Keep around a percentage of traces for extended data retentionSee results after 7 daysOptimization 2: limit usageSetting a good total traces limitCutting maximum spend with an extended data retention limitSet dev/staging limits and view total spent limit across workspacesSummaryCommunityDiscordTwitterGitHubDocs CodeLangSmith SDKPythonJS/TSMoreHomepageBlogLangChain Python DocsLangChain JS/TS DocsCopyright © 2024 LangChain, Inc.', metadata={'source': 'https://docs.smith.langchain.com/tutorials/Administrators/manage_spend', 'title': 'Optimize tracing spend on LangSmith | 🦜️🛠️ LangSmith', 'description': 'Before diving into this content, it might be helpful to read the following:', 'language': 'en'})]"
      ]
     },
     "execution_count": 30,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "response['context']"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.0"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
